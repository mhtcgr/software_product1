
public class PowerOfTwo {

	public static boolean isPowerOfTwo(int n) {
		return false;
    }
	   
}