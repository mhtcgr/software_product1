
public class HammingDistance {

	public static int hammingDistance(int x, int y){
		return -1;
	}
	   
}