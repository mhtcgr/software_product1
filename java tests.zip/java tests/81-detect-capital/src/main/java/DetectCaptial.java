
public class DetectCaptial {

	public static boolean detectCapitalUse(String word) {
		return false;
    }
	   
}