
public class BinarySearch {

	public static int search(int[] data, int target) {
		return -1;
    }
	   
}