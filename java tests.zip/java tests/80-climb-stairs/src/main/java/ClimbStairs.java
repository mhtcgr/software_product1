
public class ClimbStairs {

	public static int climbStairs(int n) {

		return 0;
	}


}
