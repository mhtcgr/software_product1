
public class Bin2Dec {

	public String bin2dec(String input){
		return null;
	}

}
