
public class Fibonacci {
	public int FibonacciN(int input){
		return 0;
	}
}
