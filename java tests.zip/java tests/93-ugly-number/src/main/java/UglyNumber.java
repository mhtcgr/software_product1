
public class UglyNumber {

	public static boolean isUgly(int num) {
			return false;
    }

}
