
public class SingleCharacterIII {

	public static char singleNumber(char[] characters) {
		return '\0';

    }
	   
}