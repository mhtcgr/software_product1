
public class CheckOddEven {

	public static boolean isOdd(int num){
	
		return false;
	}
}
