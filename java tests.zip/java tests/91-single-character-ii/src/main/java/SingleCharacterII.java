import java.util.HashMap;
import java.util.Map;

public class SingleCharacterII {

	public static char singleNumber(char[] characters) {
		return '\0';
    }
	   
}