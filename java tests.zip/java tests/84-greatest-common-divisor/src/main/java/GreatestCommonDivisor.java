
public class GreatestCommonDivisor {
	public static int gcd(int a, int b) {
		return 0;
	}
	
	public static int gcdRecursive(int a,int b){
		return 0;
		
		
	}
}
