
public class NumberComplement {

	public static int findComplement(int num) {
		return -1;
    }
	   
}