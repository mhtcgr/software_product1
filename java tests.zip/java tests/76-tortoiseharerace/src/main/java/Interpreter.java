public class Interpreter {
    Parser parser;
    AST astAfterParser;

    public Interpreter(Parser p){
        parser = p;
        astAfterParser = p.parse();
        System.out.println("After parser:"+astAfterParser.toString());
    }

    private  boolean isAbstraction(AST ast){
        return ast instanceof Abstraction;
    }
    private  boolean isApplication(AST ast){
        return ast instanceof Application;
    }
    private  boolean isIdentifier(AST ast){
        return ast instanceof Identifier;
    }

    public AST eval(){
        return evalAST(astAfterParser);
    }


    private  AST evalAST(AST ast){
        //TODO
        return null;
    }

    private AST substitute(AST node,AST value){
        return shift(-1,subst(node,shift(1,value,0),0),0);
    }

    private AST subst(AST node, AST value, int depth){
        //TODO
        return null;
    }

    private AST shift(int by, AST node,int from){
       //TODO
        return null;
    }
}