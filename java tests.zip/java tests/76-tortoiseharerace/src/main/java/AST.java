

public abstract class AST {
    public abstract String toString();
    public abstract boolean equals(AST ast);
}
