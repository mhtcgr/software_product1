

public enum TokenType {
     EOF,
     LAMBDA,
     LPAREN,
     RPAREN,
     LCID,
     DOT
}
