
public class PrintNumberInWord {
	public String Number2String(int input){
		return "-1";
	}
}
