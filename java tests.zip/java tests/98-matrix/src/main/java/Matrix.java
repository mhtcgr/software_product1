
public class Matrix {
	   
	   /**
	    * 判断m1和m2是否维度相同
	    * @param m1
	    * @param m2
	    * @return 判断结果
	    */
	   public static boolean haveSameDimension(int[][] m1, int[][] m2){
		   return false;
	   }
	   
	   /**
	    * 判断m1和m2是否维度相同
	    * @param m1
	    * @param m2
	    * @return 判断结果
	    */
	   public static boolean haveSameDimension(double[][] m1, double[][] m2){
		   return false;
	   }
	   
	   /**
	    * 将二维数组相加
	    * @param m1
	    * @param m2
	    * @return 二维数组
	    */
	   public static int[][] add(int[][] m1, int[][] m2){
		   
		   return null;
	   }
	   
	   /**
	    * 将二维数组相加
	    * @param m1
	    * @param m2
	    * @return 二维数组
	    */
	   public static double[][] add(double[][] m1, double[][] m2){
		   return null;
	   }
	   
	}