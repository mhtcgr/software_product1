
public class AddDigits {

	 public static int addDigits(int num) {

		 return 0;
	 }
}
