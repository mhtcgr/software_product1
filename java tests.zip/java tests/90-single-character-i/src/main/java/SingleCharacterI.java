import java.util.Arrays;

public class SingleCharacterI {

	public static char singleNumber(char[] characters) {
		return '\0';
    }
	   
}