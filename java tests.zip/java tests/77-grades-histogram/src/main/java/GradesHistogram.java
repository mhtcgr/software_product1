
public class GradesHistogram {
	/**
	 * 编写该方法对文件进行处理，并打印直方图，可添加新的方法
	 * @param fileName 处理的文件名
	 */
	public static void histogram(String fileName){
	}
}
