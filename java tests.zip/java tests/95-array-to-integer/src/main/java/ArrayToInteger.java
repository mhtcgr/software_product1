
public class ArrayToInteger {

	public static int getInteger(int[] numbers) {
		return 0;
    }
	   
}