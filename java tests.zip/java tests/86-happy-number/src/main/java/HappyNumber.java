
public class HappyNumber {

    public static boolean isHappy(int n) {
    	return false;
    }

}
