
public class PhoneKeyPad{

	public static String convert(String s){
		return "";
	}
}